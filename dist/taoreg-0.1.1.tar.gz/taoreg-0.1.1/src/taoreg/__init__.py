from .version import __version__

# Only export what's needed for the CLI
__all__ = ['__version__']